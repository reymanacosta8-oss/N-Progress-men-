/** N-Progress order receiver. Deploy as a Web App executing as you, accessible to anyone. */
const SHEET_NAME = 'Pedidos N-Progress';
function doPost(e) {
  try {
    const p = JSON.parse(e.postData.contents);
    if (!p || !p.name || !p.phone || !Array.isArray(p.meals) || p.meals.length < 1 || p.meals.length > 42) throw new Error('Pedido inválido');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sh = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
    if (sh.getLastRow() === 0) sh.appendRow(['Fecha','ID pedido','Cliente','Teléfono','Objetivo','Día','Comida','Cantidad','Base fija','Base 1','Base 2','Vegetal','Proteína','Notas']);
    const id = Utilities.getUuid().slice(0,8).toUpperCase();
    const now = new Date();
    const safe = v => { const s=String(v??'').slice(0,500); return /^[=+\-@]/.test(s) ? "'"+s : s; };
    const rows = p.meals.map(m => [now,id,safe(p.name),safe(p.phone),safe(p.goal),safe(m.day),safe(m.slot),Number(m.qty)||1,safe(m.fixed||''),safe(m.base1),safe(m.base2||''),safe(m.veg),safe(m.protein),safe(p.notes||'')]);
    sh.getRange(sh.getLastRow()+1,1,rows.length,14).setValues(rows);
    return ContentService.createTextOutput(JSON.stringify({ok:true,id:id})).setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:String(err)})).setMimeType(ContentService.MimeType.JSON);
  }
}
